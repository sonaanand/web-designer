var secret_number= 4;
var secret_number=prompt("guess a number");
if(secret_number==4){
	alert("correct value!!");
}
else if(secret_number>4){
	alert("number is too high!!");
}
else{
	alert("number is too low!!")
}