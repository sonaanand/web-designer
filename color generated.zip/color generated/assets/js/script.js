var random=genarateRandomcolor();
var button=document.getElementById("color");
var addbutton=document.getElementById("addbtn");
var span=document.querySelector("#clrdisplay");
var ul=document.getElementById("work");

 function color(){
	span.style.background=genarateRandomcolor();
 }
 var obj
function genarateRandomcolor(){
	var r=Math.floor(Math.random()*255);
	var g=Math.floor(Math.random()*255);
	var b=Math.floor(Math.random()*255);
	obj={
		red: r,
		green: g,
		blue: b
	};
	return "rgb(" + r + ", " + g + ", " + b +")";
	// return bgcolor="rgb(" + r + ", " + g + ", " + b +")";
	 // bgcolor="rgb(" +" red:"+ r + ", " +" green:"+ g + ", "+"blue" + b +")";
	 // return "rgb(" +" red:"+ r + ", " +" green:"+ g + ", "+"blue" + b +")";
}

function add(){ 

    var li=document.createElement("li");
    li.innerHTML = "Red : "+obj.red+" Green : "+obj.green+" Blue : "+obj.blue;
    ul.appendChild(li);
	}
function addbtn(){ 

	var li=document.createElement("li");
	li.innerHTML = "Red : "+obj.red+" Green : "+obj.green+" Blue : "+obj.blue;
	ul.prepend(li);
}

function remove(){
	ul.removeChild(ul.childNodes[0]);
}	
function removebtn(){
	ul.removeChild(ul.childNodes[0]);
}
var arr=[];
function redsort(){

	arr.push(obj);
	// console.log(arr);
	arr.sort();

}


	

	
   
