var numsquare=6;
var colors=genarateRandomcolor(numsquare);
var squares=document.querySelectorAll(".square");
var pickedclr=changeclr();
var clrdisplay=document.getElementById("colordisplay");
var msgdisplay=document.querySelector("#message");
var h1=document.querySelector("h1");

var button=document.querySelector(".easy")

var button=document.querySelector(".hard")



clrdisplay.textContent=pickedclr;
// color genarator
for(var i=0; i<squares.length;i++) {
	squares[i].style.background=colors[i];
	squares[i].addEventListener("click",function(){
	var clickclr=this.style.background;
	if(clickclr === pickedclr){
		msgdisplay.textContent="Correct!!";
		clrchange(clickclr);
		h1.style.background=clickclr;
	}else{
		this.style.background ="black";
		msgdisplay.textContent ="Try Again!";

	}
});

}
// color change
function clrchange(change){
	for(var i=0; i<numsquare; i++){
		squares[i].style.background=change;
	}
}
// rbg changes
function changeclr(){
	var random=Math.floor(Math.random()*colors.length);
	return colors[random];
}
function genarateRandomcolor(num){
	// create a array
	var arr=[]
	for(var i=0;i<num;i++){ 
	arr.push(randomcolor());
	}
	return arr;
}
function randomcolor(){
	var r=Math.floor(Math.random()*255);
	var g=Math.floor(Math.random()*255);
	var b=Math.floor(Math.random()*255);
	 return "rgb(" + r + ", " + g + ", " + b +")";
}

function reset(){
	// numsquare=6;
	colors=genarateRandomcolor(numsquare);
	pickedclr=changeclr();
	clrdisplay.textContent=pickedclr;
	for(var i=0;i<squares.length;i++){

		squares[i].style.background=colors[i];
	}
	h1.style.background="#99ccff";

}


// hard
function hard(){
	numsquare=6;
	colors=genarateRandomcolor(numsquare);
	pickedclr=changeclr();
	clrdisplay.textContent=pickedclr;
	for(var i=0;i<squares.length;i++){
		if(colors[i]){
		squares[i].style.background=colors[i];	
		squares[i].style.display="block";
		}
		
	}
}
// easy

function easy(){
	numsquare=3;
	colors=genarateRandomcolor(numsquare);
	pickedclr=changeclr();
	clrdisplay.textContent=pickedclr;
	for(var i=0;i<squares.length;i++){
		if(colors[i]){
		squares[i].style.background=colors[i];	
		}
		else{
			squares[i].style.background="black";
		}
	}
}







